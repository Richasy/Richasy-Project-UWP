﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Models.Enums
{
    public enum LanguageNames
    {
        UpdateTitle,
        Warning,
        Confirm,
        Cancel
    }
}
